﻿using PODBookingSystem.Models;
using System;

namespace PODBookingSystem.ViewModels
{
    public class BookingViewModel
    {
        public int RoomId { get; set; } // ID phòng
        public int ServicePackageId { get; set; } // ID gói dịch vụ
        public DateTime StartTime { get; set; } // Ngày và giờ bắt đầu
        public DateTime EndTime { get; set; } // Ngày và giờ kết thúc
    }
}
