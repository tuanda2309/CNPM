﻿using PODBookingSystem.Models;

namespace PODBookingSystem.ViewModels
{
    public class ProfileViewModel
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string Image { get; set; }  // Chuỗi đường dẫn hình ảnh từ DB
        public IFormFile ImageFile { get; set; }  // File dường dẫn hình ảnh
        public string Title { get; set; }
        public string Role { get; set; }
        public List<Room> BookedRooms { get; set; } = new List<Room>();
    }
}
