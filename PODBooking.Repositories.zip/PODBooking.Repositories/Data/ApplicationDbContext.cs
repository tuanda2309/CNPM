﻿using Microsoft.EntityFrameworkCore;
using PODBooking.Repositories.Models;
using PODBooking.Repositories.Models.Momo;
using PODBookingSystem.Models;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<User> Users { get; set; }
    public DbSet<Room> Rooms { get; set; }
    public DbSet<ServicePackage> ServicePackages { get; set; }
    public DbSet<Booking> Bookings { get; set; }
    public DbSet<BookingAddOn> BookingAddOns { get; set; }
    public DbSet<Payment> Payments { get; set; }
    public DbSet<Report> Reports { get; set; }
    public DbSet<Notification> Notifications { get; set; }
    public DbSet<OrderInfo> OrderInfos { get; set; }
    public DbSet<MomoInfoModel> momoInfoModels { get; set; }
    public DbSet<Bank> Banks { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Định nghĩa các khóa chính
        modelBuilder.Entity<User>().HasKey(u => u.Id);
        modelBuilder.Entity<Room>().HasKey(r => r.RoomId);
        modelBuilder.Entity<ServicePackage>().HasKey(sp => sp.ServicePackageId);
        modelBuilder.Entity<Booking>().HasKey(b => b.BookingId);
        modelBuilder.Entity<BookingAddOn>().HasKey(ba => ba.BookingAddOnId);
        modelBuilder.Entity<Payment>().HasKey(p => p.PaymentId);
        modelBuilder.Entity<Report>().HasKey(r => r.ReportId);
        modelBuilder.Entity<Notification>().HasKey(n => n.NotificationId);
        modelBuilder.Entity<OrderInfo>().HasKey(o => o.OrderId);
        modelBuilder.Entity<MomoInfoModel>().HasKey(m => m.Id);
        modelBuilder.Entity<Bank>().HasKey(b => b.BookingId);


        // Thiết lập các mối quan hệ
        modelBuilder.Entity<Booking>()
            .HasOne<Room>()
            .WithMany()
            .HasForeignKey(b => b.RoomId)
            .OnDelete(DeleteBehavior.NoAction); // Ngăn không thực hiện cascade delete

        modelBuilder.Entity<Booking>()
            .HasOne<User>()
            .WithMany()
            .HasForeignKey(b => b.UserId)
            .OnDelete(DeleteBehavior.NoAction); // Ngăn không thực hiện cascade delete

        modelBuilder.Entity<Booking>()
            .HasOne<ServicePackage>()
            .WithMany()
            .HasForeignKey(b => b.ServicePackageId)
            .OnDelete(DeleteBehavior.NoAction); // Ngăn không thực hiện cascade delete

        modelBuilder.Entity<BookingAddOn>()
            .HasOne<Booking>()
            .WithMany()
            .HasForeignKey(ba => ba.BookingId)
            .OnDelete(DeleteBehavior.Cascade); // Giữ lại cascade delete cho BookingAddOn

        modelBuilder.Entity<Payment>()
            .HasOne<Booking>()
            .WithMany()
            .HasForeignKey(p => p.BookingId)
            .OnDelete(DeleteBehavior.Cascade); // Giữ lại cascade delete cho Payment

        modelBuilder.Entity<Report>()
            .HasOne<User>()
            .WithMany()
            .HasForeignKey(r => r.UserId)
            .OnDelete(DeleteBehavior.NoAction); // Ngăn không thực hiện cascade delete

        modelBuilder.Entity<Report>()
            .HasOne<Booking>()
            .WithMany()
            .HasForeignKey(r => r.BookingId)
            .OnDelete(DeleteBehavior.NoAction); // Ngăn không thực hiện cascade delete
        modelBuilder.Entity<Notification>()
            .HasOne(n => n.User)
            .WithMany(u => u.Notifications)
            .HasForeignKey(n => n.UserId)
            .OnDelete(DeleteBehavior.Cascade);
        modelBuilder.Entity<OrderInfo>()
            .HasOne<Booking>() // Một OrderInfo có một Booking liên kết
            .WithMany()
            .HasForeignKey(o => o.BookingId) // Khóa ngoại là BookingId
            .OnDelete(DeleteBehavior.Cascade); // Xóa Booking thì xóa luôn OrderInfo
        modelBuilder.Entity<MomoInfoModel>()
            .HasOne<OrderInfo>()
            .WithMany()
            .HasForeignKey(m => m.OrderId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Bank>()
            .HasOne<Room>()
            .WithMany()
            .HasForeignKey(b => b.RoomId)
            .OnDelete(DeleteBehavior.NoAction); // Ngăn không thực hiện cascade delete

        modelBuilder.Entity<Bank>()
            .HasOne<User>()
            .WithMany()
            .HasForeignKey(b => b.UserId)
            .OnDelete(DeleteBehavior.NoAction); // Ngăn không thực hiện cascade delete

        modelBuilder.Entity<Bank>()
            .HasOne<ServicePackage>()
            .WithMany()
            .HasForeignKey(b => b.ServicePackageId)
            .OnDelete(DeleteBehavior.NoAction); // Ngăn không thực hiện cascade delete
    }
}
