﻿namespace PODBookingSystem.Models.DTOs
{
    public class ServiceAddOnDTO
    {
        public int ServiceAddOnId { get; set; }
        public string AddOnName { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
    }
}
