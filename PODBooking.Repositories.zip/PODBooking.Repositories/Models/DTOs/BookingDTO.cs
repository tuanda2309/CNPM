﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace PODBookingSystem.Models.DTOs
{
    public class BookingDTO
    {
        public int BookingId { get; set; }
        public int RoomId { get; set; } // ID của phòng
        public int CustomerId { get; set; } // ID của người dùng
        public DateTime StartTime { get; set; } // Thời gian bắt đầu
        public DateTime EndTime { get; set; } // Thời gian kết thúc
        public double TotalPrice { get; set; } // Tổng giá
        public int? ServicePackageId { get; set; } // ID gói dịch vụ (nếu có)
        public string Status { get; set; } = "Pending"; // Gán giá trị mặc định cho Status
        public List<SelectListItem> ServicePackageOptions { get; set; } = new List<SelectListItem>();
        public string? RoomName { get; set; }
        public string? CustomerName { get; set; }
    }
}
