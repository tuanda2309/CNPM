﻿namespace PODBookingSystem.Models
{
    public class Manager : User
    {
        public new string Role { get; set; } = "Manager";

    }
}
