﻿namespace PODBookingSystem.Models
{
    public class Booking
    {
        public int BookingId { get; set; } // Khóa chính
        public int? UserId { get; set; } // Khóa ngoại tham chiếu đến User
        public int RoomId { get; set; } // Khóa ngoại tham chiếu đến Room
        public int? ServicePackageId { get; set; } // Khóa ngoại tham chiếu đến ServicePackage
        public DateTime BookingDate { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public double TotalPrice { get; set; }
        public string Status { get; set; } // Đang chờ, Đã xác nhận, Đã hủy
        public string PaymentStatus { get; set; }
    }
}
