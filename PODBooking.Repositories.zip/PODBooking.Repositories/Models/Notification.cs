﻿namespace PODBookingSystem.Models
{
    public class Notification
    {
        public int NotificationId { get; set; }  // Khóa chính

        public int UserId { get; set; }  // Khóa ngoại tham chiếu đến User
        public User User { get; set; }  // Điều hướng đến User

        public int? BookingId { get; set; }  // Khóa ngoại tham chiếu đến Booking, có thể null
        public Booking Booking { get; set; }  // Điều hướng đến Booking

        public string Title { get; set; }  // Tiêu đề thông báo

        public string Message { get; set; }  // Nội dung thông báo

        public DateTime CreatedAt { get; set; }  // Thời gian tạo thông báo

        public bool IsRead { get; set; }  // Trạng thái đã đọc
    }
}
