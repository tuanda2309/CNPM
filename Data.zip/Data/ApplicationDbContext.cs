﻿using Microsoft.EntityFrameworkCore;
using PODBookingSystem.Models;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users { get; set; }
    public DbSet<Room> Rooms { get; set; }
    public DbSet<ServicePackage> ServicePackages { get; set; }
    public DbSet<ServiceAddOn> ServiceAddOns { get; set; }
    public DbSet<Booking> Bookings { get; set; }
    public DbSet<BookingAddOn> BookingAddOns { get; set; }
    public DbSet<Payment> Payments { get; set; }
    public DbSet<Report> Reports { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Định nghĩa các thực thể
        modelBuilder.Entity<User>().HasKey(u => u.Id);
        modelBuilder.Entity<Room>().HasKey(r => r.RoomId);
        modelBuilder.Entity<ServicePackage>().HasKey(sp => sp.ServicePackageId);
        modelBuilder.Entity<ServiceAddOn>().HasKey(sa => sa.ServiceAddOnId);
        modelBuilder.Entity<Booking>().HasKey(b => b.BookingId);
        modelBuilder.Entity<BookingAddOn>().HasKey(ba => ba.BookingAddOnId);
        modelBuilder.Entity<Payment>().HasKey(p => p.PaymentId);
        modelBuilder.Entity<Report>().HasKey(r => r.ReportId);

        // Thiết lập các mối quan hệ
        modelBuilder.Entity<Booking>()
            .HasOne<Room>() // Không cần navigation property
            .WithMany() // Không cần chỉ định navigation property ở phía Room
            .HasForeignKey(b => b.RoomId);
        modelBuilder.Entity<Report>()
            .HasOne<User>()  // Xác định bảng khóa ngoại (Users)
            .WithMany()      // Không dùng navigation property
            .HasForeignKey(r => r.UserId)  // Khóa ngoại từ bảng Reports
            .OnDelete(DeleteBehavior.NoAction); // Không th

        modelBuilder.Entity<Booking>()
            .HasOne<User>()
            .WithMany()
            .HasForeignKey(b => b.UserId);

        modelBuilder.Entity<Booking>()
            .HasOne<ServicePackage>()
            .WithMany()
            .HasForeignKey(b => b.ServicePackageId);

        modelBuilder.Entity<BookingAddOn>()
            .HasOne<Booking>()
            .WithMany()
            .HasForeignKey(ba => ba.BookingId);

        modelBuilder.Entity<BookingAddOn>()
            .HasOne<ServiceAddOn>()
            .WithMany()
            .HasForeignKey(ba => ba.ServiceAddOnId);

        modelBuilder.Entity<Payment>()
            .HasOne<Booking>()
            .WithMany()
            .HasForeignKey(p => p.BookingId);

        modelBuilder.Entity<Report>()
            .HasOne<User>()
            .WithMany()
            .HasForeignKey(r => r.UserId);

        modelBuilder.Entity<Report>()
            .HasOne<Booking>()
            .WithMany()
            .HasForeignKey(r => r.BookingId);
    }

}
