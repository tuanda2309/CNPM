﻿using PODBookingSystem.Models.DTOs;
using PODBookingSystem.Models;

namespace PODBookingSystem.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly ApplicationDbContext _context;

        public PaymentService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<PaymentDTO> ProcessPayment(PaymentDTO paymentDto)
        {
            var payment = new Payment
            {
                BookingId = paymentDto.BookingId,
                Amount = paymentDto.Amount,
                PaymentMethod = paymentDto.PaymentMethod,
                PaymentStatus = "Pending"
            };

            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

            return new PaymentDTO
            {
                PaymentId = payment.PaymentId,
                BookingId = payment.BookingId,
                Amount = payment.Amount,
                PaymentStatus = payment.PaymentStatus
            };
        }

        public async Task<bool> ConfirmPayment(int paymentId)
        {
            var payment = await _context.Payments.FindAsync(paymentId);
            if (payment == null) return false;

            payment.PaymentStatus = "Paid";
            _context.Payments.Update(payment);
            await _context.SaveChangesAsync();

            return true;
        }

        Task<bool> IPaymentService.ProcessPayment(PaymentDTO paymentDto)
        {
            throw new NotImplementedException();
        }

        public Task<PaymentDTO> GetPaymentById(int paymentId)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<PaymentDTO>> GetPaymentsByUserId(int userId)
        {
            throw new NotImplementedException();
        }

        public Task<bool> CancelPayment(int paymentId)
        {
            throw new NotImplementedException();
        }
    }
}

