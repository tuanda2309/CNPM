﻿using PODBookingSystem.Models.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PODBookingSystem.Services
{
    public interface IServicePackageService
    {
        Task<IEnumerable<ServicePackageDTO>> GetAllServicePackages();
        Task<ServicePackageDTO> GetServicePackageById(int id);
        Task<ServicePackageDTO> CreateServicePackage(ServicePackageDTO servicePackageDto);
        Task<bool> UpdateServicePackage(ServicePackageDTO servicePackageDto);
        Task<bool> DeleteServicePackage(int id);
    }
}
