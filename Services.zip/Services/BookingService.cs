﻿using Microsoft.EntityFrameworkCore;
using PODBookingSystem.Models;
using PODBookingSystem.Models.DTOs;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PODBookingSystem.Services
{
    public class BookingService : IBookingService
    {
        private readonly ApplicationDbContext _context;

        public BookingService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<BookingDTO> CreateBooking(BookingDTO bookingDto)
        {
            if (bookingDto.IsHourly)
            {
                // Kiểm tra phòng có trống không cho đặt theo giờ
                if (!await CheckRoomAvailability(bookingDto.RoomId, bookingDto.StartTime, bookingDto.EndTime))
                {
                    bookingDto.Status = "Failed";
                    return bookingDto;
                }
            }
            else
            {
                // Kiểm tra phòng có trống không cho đặt theo gói dịch vụ
                var servicePackage = await _context.ServicePackages.FindAsync(bookingDto.ServicePackageId);
                if (servicePackage == null || !await CheckRoomAvailability(bookingDto.RoomId, bookingDto.StartTime, bookingDto.EndTime))
                {
                    bookingDto.Status = "Failed";
                    return bookingDto;
                }
                bookingDto.TotalPrice = servicePackage.Price; // Thiết lập giá từ gói dịch vụ
            }

            // Tạo mới một booking
            var booking = new Booking
            {
                RoomId = bookingDto.RoomId,
                UserId = bookingDto.UserId,
                StartTime = bookingDto.StartTime,
                EndTime = bookingDto.EndTime,
                TotalPrice = bookingDto.TotalPrice,
                Status = "Pending" // Mặc định là Pending
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            bookingDto.Status = "Pending"; // Trạng thái đặt chỗ
            return bookingDto;
        }

        public async Task<bool> CheckRoomAvailability(int roomId, DateTime startDate, DateTime endDate)
        {
            // Kiểm tra xem phòng có bị đặt trong khoảng thời gian đã chọn không
            var isBooked = await _context.Bookings.AnyAsync(b =>
                b.RoomId == roomId &&
                b.Status != "Cancelled" &&
                ((b.StartTime <= endDate && b.EndTime >= startDate)));

            return !isBooked; // Nếu chưa bị đặt, trả về true (phòng trống)
        }

        public async Task<List<BookingDTO>> GetUserBookings(int userId)
        {
            var bookings = await _context.Bookings
                .Where(b => b.UserId == userId)
                .Select(b => new BookingDTO
                {
                    RoomId = b.RoomId,
                    UserId = b.UserId,
                    StartTime = b.StartTime,
                    EndTime = b.EndTime,
                    TotalPrice = b.TotalPrice,
                    Status = b.Status,
                    ServicePackageId = b.ServicePackageId // Thêm ID gói dịch vụ nếu có
                })
                .ToListAsync();

            return bookings; // Trả về danh sách đặt phòng
        }

        public async Task<bool> CancelBooking(int bookingId)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking != null)
            {
                booking.Status = "Cancelled"; // Đánh dấu đặt phòng là đã hủy
                await _context.SaveChangesAsync();
                return true;
            }
            return false; // Nếu không tìm thấy đặt phòng
        }
        public async Task<IEnumerable<ServicePackageDTO>> GetAllServicePackages()
        {
            return await _context.ServicePackages
                .Select(sp => new ServicePackageDTO
                {
                    ServicePackageId = sp.ServicePackageId,
                    Name = sp.Name,
                    Price = sp.Price
                }).ToListAsync();
        }

        public Task<bool> CheckRoomAvailability(int roomId, DateTime startDate, DateTime endDate, double TotalPrice)
        {
            throw new NotImplementedException();
        }

    }
}
