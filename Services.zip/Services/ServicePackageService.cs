﻿using Microsoft.EntityFrameworkCore;
using PODBookingSystem.Models;
using PODBookingSystem.Models.DTOs;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PODBookingSystem.Services
{
    public class ServicePackageService : IServicePackageService
    {
        private readonly ApplicationDbContext _context;

        public ServicePackageService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<ServicePackageDTO>> GetAllServicePackages()
        {
            return await _context.ServicePackages
                .Select(sp => new ServicePackageDTO
                {
                    ServicePackageId = sp.ServicePackageId,
                    Name = sp.Name,
                    Description = sp.Description,
                    Price = sp.Price
                }).ToListAsync();
        }

        public async Task<ServicePackageDTO> GetServicePackageById(int id)
        {
            var servicePackage = await _context.ServicePackages.FindAsync(id);
            if (servicePackage == null) return null;

            return new ServicePackageDTO
            {
                ServicePackageId = servicePackage.ServicePackageId,
                Name = servicePackage.Name,
                Description = servicePackage.Description,
                Price = servicePackage.Price
            };
        }

        public async Task<ServicePackageDTO> CreateServicePackage(ServicePackageDTO servicePackageDto)
        {
            var servicePackage = new ServicePackage
            {
                Name = servicePackageDto.Name,
                Description = servicePackageDto.Description,
                Price = servicePackageDto.Price,
                CreatedAt = DateTime.UtcNow
            };

            _context.ServicePackages.Add(servicePackage);
            await _context.SaveChangesAsync();

            servicePackageDto.ServicePackageId = servicePackage.ServicePackageId;
            return servicePackageDto;
        }

        public async Task<bool> UpdateServicePackage(ServicePackageDTO servicePackageDto)
        {
            var servicePackage = await _context.ServicePackages.FindAsync(servicePackageDto.ServicePackageId);
            if (servicePackage == null) return false;

            servicePackage.Name = servicePackageDto.Name;
            servicePackage.Description = servicePackageDto.Description;
            servicePackage.Price = servicePackageDto.Price;

            _context.ServicePackages.Update(servicePackage);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteServicePackage(int id)
        {
            var servicePackage = await _context.ServicePackages.FindAsync(id);
            if (servicePackage == null) return false;

            _context.ServicePackages.Remove(servicePackage);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
