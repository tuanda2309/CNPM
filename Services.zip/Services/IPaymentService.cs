﻿using System.Threading.Tasks;
using PODBookingSystem.Models.DTOs;

namespace PODBookingSystem.Services
{
    public interface IPaymentService
    {
        Task<bool> ProcessPayment(PaymentDTO paymentDto);
        Task<PaymentDTO> GetPaymentById(int paymentId);
        Task<IEnumerable<PaymentDTO>> GetPaymentsByUserId(int userId);
        Task<bool> CancelPayment(int paymentId);
    }
}
