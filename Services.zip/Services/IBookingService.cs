﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PODBookingSystem.Models.DTOs;

namespace PODBookingSystem.Services
{
    public interface IBookingService
    {
        Task<BookingDTO> CreateBooking(BookingDTO bookingDto);
        Task<bool> CheckRoomAvailability(int roomId, DateTime startDate, DateTime endDate,double TotalPrice);
        Task<List<BookingDTO>> GetUserBookings(int userId);
        Task<bool> CancelBooking(int bookingId);
        Task<IEnumerable<ServicePackageDTO>> GetAllServicePackages();
    }
}
