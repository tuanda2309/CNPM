﻿using PODBookingSystem.Models;

namespace PODBookingSystem.Services
{
    public interface ICustomerService
    {
        List<Room> GetAvailableRooms();
        void BookRoom(Booking booking);
        User GetUserProfile();
        void PurchasePackage(ServicePackage package);
        List<Booking> GetBookingHistory();
    }
}
